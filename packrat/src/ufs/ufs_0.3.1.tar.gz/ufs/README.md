
ufs 📦
=====

ufs: A leaner, cleaner version of the userfriendlyscience package

[![Pipeline status](https://gitlab.com/r-packages/ufs/badges/master/pipeline.svg)](https://gitlab.com/r-packages/ufs/commits/master)

[![Coverage status](https://codecov.io/gl/r-packages/ufs/branch/master/graph/badge.svg)](https://codecov.io/gl/r-packages/ufs?branch=master)

Installation
------------

You can install the released version of `ufs` from [CRAN](https://CRAN.R-project.org) with:

``` r
install.packages('ufs');
```

You can install the development version of `ufs` from [GitLab](https://gitlab.com) with:

``` r
devtools::install_gitlab('r-packages/ufs');
```

(assuming you have `devtools` installed; otherwise, install that first using the `install.packages` function)
