###########################################################
###########################################################
###
### Collection of very basic functions
###
### File created by Gjalt-Jorn Peters. Questions? You can
### contact me through http://behaviorchange.eu.
###
###########################################################
###########################################################

noZero <- ufs::noZero;

formatR <- ufs::formatR;

ifelseObj <- ufs::ifelseObj;

is.odd <- ufs::is.odd
is.even <- ufs::is.even

`%IN%` <- ufs::`%IN%`;

cat0 <- ufs::cat0;

isTrue <- ufs::isTrue;

is.nr <- ufs::is.nr;
