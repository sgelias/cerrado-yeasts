vecTxtQ <- ufs::vecTxtQ;

vecTxt <- ufs::vecTxt;
