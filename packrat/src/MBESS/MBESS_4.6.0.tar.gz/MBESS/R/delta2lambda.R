delta2lambda <- function(delta, n.1, n.2)
{
return(delta*sqrt((n.2*n.1)/(n.1+n.2)))
}
