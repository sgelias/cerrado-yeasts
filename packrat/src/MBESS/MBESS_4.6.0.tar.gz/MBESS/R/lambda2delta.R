lambda2delta <- function(lambda, n.1, n.2)
{
return(lambda*sqrt((n.2 + n.1)/(n.1*n.2)))
}
