## SuppDists-defunct.R
rziggurat <- function(...) {
  .Defunct(new = "RcppZiggurat::zrnorm",
           package = "SuppDists")
}

rMWC1019 <- function(...) {
  .Defunct(package = "SuppDists")
}
